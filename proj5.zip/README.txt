Group members:
  Jennifer Kim (kim00954)
  Matthew Vilaysack (vilay016)

Contributions:
  We both worked on it in call and attended office hours when we needed help together.

How to compile:
  javac HashTable.java

Additional Features: no
Known bugs or defects: - No known bugs/defects
Outside sources:
 - https://computinglife.wordpress.com/2008/11/20/why-do-hash-functions-use-prime-numbers/
 - algorithm from TextScan.java
 - https://phpfog.com/how-to-create-a-hash-table-in-java-chaining-example/